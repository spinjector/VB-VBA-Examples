﻿
Imports System.Net
Imports System.IO

Public Class frmTest

    Private Sub frmTest_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ToolStripButton4_Click(sender As Object, e As EventArgs) Handles ToolStripButton4.Click
        WebBrowser1.Navigate(ToolStripComboBoxSpring1.Text)
    End Sub


    Private Sub WebBrowser1_Navigated(sender As Object, e As WebBrowserNavigatedEventArgs) Handles WebBrowser1.Navigated
        Dim webclient As New WebClient
        Dim iconUrl As New Uri(WebBrowser1.Url.ToString)
        Dim stream As New MemoryStream(webclient.DownloadData("http://" & iconUrl.Authority & "/favicon.ico"))
        Dim favicon As New Icon(stream)
        PictureBox1.Image = favicon.ToBitmap
    End Sub
End Class