﻿Public Class frmLauncher

    'Private currentlyAssembly As System.Reflection.Assembly = System.Reflection.Assembly.GetExecutingAssembly()
    'Private typesInAssembly() As Type = currentAssembly.DefinedTypes
    '' other way Private myTypes() As Type = myAssembly.GetTypes

    'Private Sub FormLoad(sender As Object, e As EventArgs) Handles MyBase.Load
    '    For Each t In typesInAssembly
    '        Dim n As String = t.BaseType.Name
    '        If Not lstTypes.Items.Contains(n) Then
    '            lstTypes.Items.Add(n)
    '        End If
    '    Next
    '    sslTypes.Text = lstTypes.Items.Count.ToString & " items."
    'End Sub

    'Private Sub SomethingElse()
    '    For Each t In typesInAssembly
    '        If t.BaseType.FullName.ToString.ToUpper = "System.Windows.Forms.Form".ToUpper Then
    '            lstItems.Items.Add(t.FullName)
    '        End If
    '    Next
    'End Sub

    'Private Sub LaunchItem(sender As Object, e As EventArgs) Handles lstItems.DoubleClick, btnLaunch.Click
    '    Dim frmName As String = lstItems.Text
    '    Dim obj = currentAssembly.GetType(frmName).InvokeMember(Nothing, Reflection.BindingFlags.CreateInstance, Nothing, Nothing, Nothing)
    '    Dim frm As Form = CType(obj, System.Windows.Forms.Form)
    '    frm.Show()
    '    If chkCloseAfter.Checked Then Me.Close()
    'End Sub

End Class