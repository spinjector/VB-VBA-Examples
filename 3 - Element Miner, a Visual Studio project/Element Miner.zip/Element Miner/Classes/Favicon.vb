﻿Public Class Favicon
    '                    If text.Contains("icon") Then MsgBox(text)

End Class
