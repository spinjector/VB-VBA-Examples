﻿Module WebBrowserProcedures

    Friend Enum WebBrowserExec
        OLECMDID_OPEN = 1
        OLECMDID_NEW = 2
        OLECMDID_SAVE = 3
        OLECMDID_SAVEAS = 4
        OLECMDID_SAVECOPYAS = 5
        OLECMDID_PRINT = 6
        OLECMDID_PRINTPREVIEW = 7
        OLECMDID_PAGESETUP = 8
        OLECMDID_SPELL = 9
        OLECMDID_PROPERTIES = 10
        OLECMDID_CUT = 11
        OLECMDID_COPY = 12
        OLECMDID_PASTE = 13
        OLECMDID_PASTESPECIAL = 14
        OLECMDID_UNDO = 15
        OLECMDID_REDO = 16
        OLECMDID_SELECTALL = 17
        OLECMDID_CLEARSELECTION = 18
        OLECMDID_ZOOM = 19
        OLECMDID_GETZOOMRANGE = 20
        OLECMDID_UPDATECOMMANDS = 21
        OLECMDID_REFRESH = 22
        OLECMDID_STOP = 23
        OLECMDID_HIDETOOLBARS = 24
        OLECMDID_SETPROGRESSMAX = 25
        OLECMDID_SETPROGRESSPOS = 26
        OLECMDID_SETPROGRESSTEXT = 27
        OLECMDID_SETTITLE = 28
        OLECMDID_SETDOWNLOADSTATE = 29
        OLECMDID_STOPDOWNLOAD = 30
        OLECMDID_ONTOOLBARACTIVATED = 31
        OLECMDID_FIND = 32
        OLECMDID_DELETE = 33
        OLECMDID_HTTPEQUIV = 34
        OLECMDID_HTTPEQUIV_DONE = 35
        OLECMDID_ENABLE_INTERACTION = 36
        OLECMDID_ONUNLOAD = 37
        OLECMDID_PROPERTYBAG2 = 38
        OLECMDID_PREREFRESH = 39
        OLECMDID_SHOWSCRIPTERROR = 40
        OLECMDID_SHOWMESSAGE = 41
        OLECMDID_SHOWFIND = 42
        OLECMDID_SHOWPAGESETUP = 43
        OLECMDID_SHOWPRINT = 44
        OLECMDID_CLOSE = 45
        OLECMDID_ALLOWUILESSSAVEAS = 46
        OLECMDID_DONTDOWNLOADCSS = 47
        OLECMDID_UPDATEPAGESTATUS = 48
        OLECMDID_PRINT2 = 49
        OLECMDID_PRINTPREVIEW2 = 50
        OLECMDID_SETPRINTTEMPLATE = 51
        OLECMDID_GETPRINTTEMPLATE = 52
        OLECMDID_PAGEACTIONBLOCKED = 55
        OLECMDID_PAGEACTIONUIQUERY = 56
        OLECMDID_FOCUSVIEWCONTROLS = 57
        OLECMDID_FOCUSVIEWCONTROLSQUERY = 58
        OLECMDID_SHOWPAGEACTIONMENU = 59
        OLECMDID_ADDTRAVELENTRY = 60
        OLECMDID_UPDATETRAVELENTRY = 61
        OLECMDID_UPDATEBACKFORWARDSTATE = 62
        OLECMDID_OPTICAL_ZOOM = 63
        OLECMDID_OPTICAL_GETZOOMRANGE = 64
        OLECMDID_WINDOWSTATECHANGED = 65
        OLECMDID_ACTIVEXINSTALLSCOPE = 66
        OLECMDID_UPDATETRAVELENTRY_DATARECOVERY = 67
    End Enum

    Friend Enum WebBrowserExecOpt
        OLECMDEXECOPT_DODEFAULT = 0
        OLECMDEXECOPT_PROMPTUSER = 1
        OLECMDEXECOPT_DONTPROMPTUSER = 2
        OLECMDEXECOPT_SHOWHELP = 3
    End Enum

    Friend Sub WebBrowserPerformZoom(ByRef WebBrowserControlInstance As Object, ByVal ZoomFactor As Integer)
        Dim browserCurrentInstance As Object
        Try
            browserCurrentInstance = WebBrowserControlInstance.ActiveXInstance
            browserCurrentInstance.ExecWB(WebBrowserExec.OLECMDID_OPTICAL_ZOOM, WebBrowserExecOpt.OLECMDEXECOPT_PROMPTUSER, CObj(ZoomFactor), CObj(IntPtr.Zero))
        Catch ThisException As Exception
            Dim message As String = ""
            message &= "There was an error while zooming the WebBrowser control named '" & 1 & "'." & vbCrLf
            message &= vbCrLf
            message &= ThisException.Message
            MessageBox.Show(message, "Error While Performing Zoom", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub test()
        'Try
        '    Dim Res As Object = Nothing
        '    Dim browserCurrentInstance As Object
        '    browserCurrentInstance = Me.browserWindow.ActiveXInstance
        '    browserCurrentInstance.ExecWB(WebBrowserExec.OLECMDID_OPTICAL_ZOOM, WebBrowserExecOpt.OLECMDEXECOPT_PROMPTUSER, CObj(Value), CObj(IntPtr.Zero))
        'Catch ThisException As Exception
        '    Dim message As String = ""
        '    message &= "There was an error while zooming a WebBrowser control." & vbCrLf
        '    message &= vbCrLf
        '    message &= ThisException.Message
        '    MessageBox.Show(message, "Error While Performing Zoom", MessageBoxButtons.OK, MessageBoxIcon.Error)
        'End Try

        ' If you use the WebBrowser control in your program and want to have the same page zoom function (as shown in IE), you can send it to IWebBrowser2.OLECMDID_OPTICAL_GETZOOMRANGE,OLECMDID_OPTICAL_ZOOMCommand to achieve. Sample code is as follows:

        'The range of scaling:
        'VarRange CComVariant;
        'SpWebBrowser->ExecWB (OLECMDID_OPTICAL_GETZOOMRANGE, OLECMDEXECOPT_DODEFAULT, NULL, &varRange);
        'ASSERT (V_VT (&varRange) = VT_I4);
        'WMinZoom WORD = LOWORD (V_I4 (&varRange));/ / minimum zoom ratio
        'WMaxZoom WORD = HIWORD (V_I4 (&varRange));/ / maximum zoom

        'Get current scaling:
        'VarZoom CComVariant;
        'SpWebBrowser->ExecWB (OLECMDID_OPTICAL_ZOOM, OLECMDEXECOPT_DODEFAULT, NULL, &varZoom);
        'ASSERT (V_VT (&varZoom) = VT_I4);
        'UlZoom ULONG = V_I4 (&varZoom);/ / the current zoom, 100 represents 100%, namely the original size

        'Set scaling ratio:
        'VarZoom CComVariant ((int) nZoom);/ / nZoom is to set the zoom ratio
        'SpWebBrowser->ExecWB (OLECMDID_OPTICAL_ZOOM, OLECMDEXECOPT_DODEFAULT, &varZoom, NULL);

        ' Note:OLECMDID_OPTICAL_GETZOOMRANGE, OLECMDID_OPTICAL_ZOOM fromIE7To begin with, the IE6 and
        ' the previous version, please use OLECMDID_GETZOOMRANGE, OLECMDID_ZOOM. Need to pay attention to is,
        ' IE6 and earlier versions can only be scaled, but many web pages with CSS fixed the size of the font, 
        ' so most of the time the effect is not ideal. From the beginning of the IE, the IE7 page zoom function 
        ' is redesigned, the entire page can be vector zoom (picture, edit box, etc.). IE8 optimizes the performance
        ' of scaling, and adds some of the smart page elements to adjust, so that the scaling effect is more smooth.

    End Sub

    ' Attempts to navigate to the URL in the address textbox if it is valid.
    Friend Sub browserNavigate(ByRef browserWindow As Windows.Forms.WebBrowser, ByVal address As String)
        If String.IsNullOrEmpty(address) Then Return
        If address.Equals("about:blank") Then Return
        If Not address.StartsWith("http://") And Not address.StartsWith("https://") Then
            address = "http://" & address
        End If
        Try
            browserWindow.Navigate(New Uri(address))
        Catch ex As System.UriFormatException
            Return
        End Try
    End Sub

End Module
