﻿Module ProjectProcedures

    Friend Sub notYetImplmented()
        MsgBox("Not yet implemented.")
    End Sub

    ' Fill the Element List control with DOM elements from the browser control.
    Friend Sub ElementListPopulate(ByRef SourceControl As Windows.Forms.WebBrowser, ByRef TargetControl As Windows.Forms.Control)
        Dim t As System.Type = TargetControl.GetType
        Select Case t
            Case GetType(ListBox), GetType(ComboBox)
                For Each element As System.Windows.Forms.HtmlElement In SourceControl.Document.All
                    Dim text As String
                    Select Case True
                        Case element.InnerText IsNot Nothing
                            text = element.InnerText.ToString
                        Case element.OuterText IsNot Nothing
                            text = element.OuterText.ToString
                        Case element.InnerHtml IsNot Nothing
                            text = element.InnerHtml.ToString
                        Case element.OuterHtml IsNot Nothing
                            text = element.OuterHtml.ToString
                        Case Else
                            text = "Null"
                    End Select
                    CTypeDynamic(TargetControl, t).Items.Add(text)
                    'If text.Contains("icon") Then CTypeDynamic(TargetControl, t)

                Next
        End Select
    End Sub

    Friend Sub ListboxFill(ByRef SourceControl As Windows.Forms.WebBrowser, ByRef TargetControl As Windows.Forms.Control)
        Dim typ As System.Type = TargetControl.GetType
        Select Case typ
            Case GetType(ListBox), GetType(ComboBox)
                CTypeDynamic(TargetControl, typ).Items.Add(SourceControl.DocumentTitle)
        End Select
    End Sub


End Module
