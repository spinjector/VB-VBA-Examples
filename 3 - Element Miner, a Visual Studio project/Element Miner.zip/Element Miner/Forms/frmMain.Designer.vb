﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.browserWindow = New System.Windows.Forms.WebBrowser()
        Me.btnDebug = New System.Windows.Forms.Button()
        Me.browserStatusbar = New System.Windows.Forms.StatusStrip()
        Me.browserStatusbarLabel = New System.Windows.Forms.ToolStripStatusLabel()
        Me.browserProgress = New System.Windows.Forms.ToolStripProgressBar()
        Me.browserToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.browserZoomIn = New System.Windows.Forms.ToolStripButton()
        Me.browserZoomOut = New System.Windows.Forms.ToolStripButton()
        Me.browserConfigure = New System.Windows.Forms.ToolStripButton()
        Me.browserSwitchTo = New System.Windows.Forms.ToolStripDropDownButton()
        Me.browserSwitchToChrome = New System.Windows.Forms.ToolStripMenuItem()
        Me.browserSwitchToFirefox = New System.Windows.Forms.ToolStripMenuItem()
        Me.browserSwitchToIe = New System.Windows.Forms.ToolStripMenuItem()
        Me.browserTitleStrip = New System.Windows.Forms.StatusStrip()
        Me.browserFavicon = New System.Windows.Forms.ToolStripStatusLabel()
        Me.browserTitleStripLabel = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.browserHome = New System.Windows.Forms.ToolStripButton()
        Me.browserSearch = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.browserBack = New System.Windows.Forms.ToolStripButton()
        Me.browserForward = New System.Windows.Forms.ToolStripButton()
        Me.browserRefresh = New System.Windows.Forms.ToolStripButton()
        Me.browserStop = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.browserGo = New System.Windows.Forms.ToolStripButton()
        Me.browserAddress = New Element_Miner.ToolStripComboBoxSpring()
        Me.btnTestThing = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.ToolStripContainer1 = New System.Windows.Forms.ToolStripContainer()
        Me.ToolStrip2 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripComboBoxSpring1 = New Element_Miner.ToolStripComboBoxSpring()
        Me.ToolStripTextBoxSpring1 = New Element_Miner.ToolStripTextBoxSpring()
        Me.browserStatusbar.SuspendLayout()
        Me.browserTitleStrip.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.ToolStripContainer1.BottomToolStripPanel.SuspendLayout()
        Me.ToolStripContainer1.ContentPanel.SuspendLayout()
        Me.ToolStripContainer1.TopToolStripPanel.SuspendLayout()
        Me.ToolStripContainer1.SuspendLayout()
        Me.ToolStrip2.SuspendLayout()
        Me.SuspendLayout()
        '
        'browserWindow
        '
        Me.browserWindow.Location = New System.Drawing.Point(64, 48)
        Me.browserWindow.MinimumSize = New System.Drawing.Size(20, 20)
        Me.browserWindow.Name = "browserWindow"
        Me.browserWindow.Size = New System.Drawing.Size(376, 196)
        Me.browserWindow.TabIndex = 0
        '
        'btnDebug
        '
        Me.btnDebug.Location = New System.Drawing.Point(16, 392)
        Me.btnDebug.Name = "btnDebug"
        Me.btnDebug.Size = New System.Drawing.Size(104, 23)
        Me.btnDebug.TabIndex = 3
        Me.btnDebug.Text = "Force Debug Now"
        Me.btnDebug.UseVisualStyleBackColor = True
        '
        'browserStatusbar
        '
        Me.browserStatusbar.Dock = System.Windows.Forms.DockStyle.None
        Me.browserStatusbar.ImageScalingSize = New System.Drawing.Size(18, 18)
        Me.browserStatusbar.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.browserStatusbarLabel, Me.browserProgress, Me.browserToolStripSeparator2, Me.browserZoomIn, Me.browserZoomOut, Me.browserConfigure, Me.browserSwitchTo})
        Me.browserStatusbar.Location = New System.Drawing.Point(0, 0)
        Me.browserStatusbar.Name = "browserStatusbar"
        Me.browserStatusbar.Size = New System.Drawing.Size(536, 24)
        Me.browserStatusbar.SizingGrip = False
        Me.browserStatusbar.TabIndex = 1
        '
        'browserStatusbarLabel
        '
        Me.browserStatusbarLabel.Name = "browserStatusbarLabel"
        Me.browserStatusbarLabel.Size = New System.Drawing.Size(313, 19)
        Me.browserStatusbarLabel.Spring = True
        Me.browserStatusbarLabel.Text = "ToolStripStatusLabel1"
        Me.browserStatusbarLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'browserProgress
        '
        Me.browserProgress.Name = "browserProgress"
        Me.browserProgress.Size = New System.Drawing.Size(100, 18)
        '
        'browserToolStripSeparator2
        '
        Me.browserToolStripSeparator2.Name = "browserToolStripSeparator2"
        Me.browserToolStripSeparator2.Size = New System.Drawing.Size(6, 24)
        '
        'browserZoomIn
        '
        Me.browserZoomIn.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.browserZoomIn.Image = Global.Element_Miner.My.Resources.Resources.zoom_in
        Me.browserZoomIn.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.browserZoomIn.Name = "browserZoomIn"
        Me.browserZoomIn.Size = New System.Drawing.Size(23, 22)
        Me.browserZoomIn.Text = "ToolStripButton1"
        Me.browserZoomIn.ToolTipText = "Zoom In"
        '
        'browserZoomOut
        '
        Me.browserZoomOut.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.browserZoomOut.Image = Global.Element_Miner.My.Resources.Resources.zoom_out
        Me.browserZoomOut.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.browserZoomOut.Name = "browserZoomOut"
        Me.browserZoomOut.Size = New System.Drawing.Size(23, 22)
        Me.browserZoomOut.Text = "ToolStripButton1"
        Me.browserZoomOut.ToolTipText = "Zoom Out"
        '
        'browserConfigure
        '
        Me.browserConfigure.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.browserConfigure.Image = Global.Element_Miner.My.Resources.Resources.settings
        Me.browserConfigure.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.browserConfigure.Name = "browserConfigure"
        Me.browserConfigure.Size = New System.Drawing.Size(23, 22)
        Me.browserConfigure.Text = "ToolStripButton1"
        Me.browserConfigure.ToolTipText = "Configure This Browser Window"
        '
        'browserSwitchTo
        '
        Me.browserSwitchTo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.browserSwitchTo.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.browserSwitchToChrome, Me.browserSwitchToFirefox, Me.browserSwitchToIe})
        Me.browserSwitchTo.Image = CType(resources.GetObject("browserSwitchTo.Image"), System.Drawing.Image)
        Me.browserSwitchTo.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.browserSwitchTo.Name = "browserSwitchTo"
        Me.browserSwitchTo.Size = New System.Drawing.Size(31, 22)
        Me.browserSwitchTo.ToolTipText = "Switch browser to..."
        '
        'browserSwitchToChrome
        '
        Me.browserSwitchToChrome.Name = "browserSwitchToChrome"
        Me.browserSwitchToChrome.Size = New System.Drawing.Size(212, 22)
        Me.browserSwitchToChrome.Text = "Switch to Chrome"
        Me.browserSwitchToChrome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'browserSwitchToFirefox
        '
        Me.browserSwitchToFirefox.Name = "browserSwitchToFirefox"
        Me.browserSwitchToFirefox.Size = New System.Drawing.Size(212, 22)
        Me.browserSwitchToFirefox.Text = "Switch to Firefox"
        Me.browserSwitchToFirefox.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'browserSwitchToIe
        '
        Me.browserSwitchToIe.Name = "browserSwitchToIe"
        Me.browserSwitchToIe.Size = New System.Drawing.Size(212, 22)
        Me.browserSwitchToIe.Text = "Switch to Internet Explorer"
        '
        'browserTitleStrip
        '
        Me.browserTitleStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.browserTitleStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.browserTitleStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.browserFavicon, Me.browserTitleStripLabel})
        Me.browserTitleStrip.Location = New System.Drawing.Point(280, 392)
        Me.browserTitleStrip.Name = "browserTitleStrip"
        Me.browserTitleStrip.Size = New System.Drawing.Size(43, 29)
        Me.browserTitleStrip.SizingGrip = False
        Me.browserTitleStrip.TabIndex = 2
        '
        'browserFavicon
        '
        Me.browserFavicon.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.browserFavicon.BorderStyle = System.Windows.Forms.Border3DStyle.Etched
        Me.browserFavicon.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.browserFavicon.Image = Global.Element_Miner.My.Resources.Resources.home
        Me.browserFavicon.Margin = New System.Windows.Forms.Padding(1, 3, 1, 2)
        Me.browserFavicon.Name = "browserFavicon"
        Me.browserFavicon.Size = New System.Drawing.Size(24, 24)
        '
        'browserTitleStripLabel
        '
        Me.browserTitleStripLabel.Name = "browserTitleStripLabel"
        Me.browserTitleStripLabel.Size = New System.Drawing.Size(2, 24)
        Me.browserTitleStripLabel.Spring = True
        Me.browserTitleStripLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.browserHome, Me.browserSearch, Me.ToolStripSeparator1, Me.browserBack, Me.browserForward, Me.browserRefresh, Me.browserStop, Me.ToolStripSeparator2, Me.browserGo})
        Me.ToolStrip1.Location = New System.Drawing.Point(584, 384)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(176, 25)
        Me.ToolStrip1.TabIndex = 3
        '
        'browserHome
        '
        Me.browserHome.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.browserHome.Image = CType(resources.GetObject("browserHome.Image"), System.Drawing.Image)
        Me.browserHome.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.browserHome.Name = "browserHome"
        Me.browserHome.Size = New System.Drawing.Size(23, 22)
        Me.browserHome.Text = "ToolStripButton1"
        '
        'browserSearch
        '
        Me.browserSearch.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.browserSearch.Image = CType(resources.GetObject("browserSearch.Image"), System.Drawing.Image)
        Me.browserSearch.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.browserSearch.Name = "browserSearch"
        Me.browserSearch.Size = New System.Drawing.Size(23, 22)
        Me.browserSearch.Text = "ToolStripButton2"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'browserBack
        '
        Me.browserBack.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.browserBack.Image = CType(resources.GetObject("browserBack.Image"), System.Drawing.Image)
        Me.browserBack.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.browserBack.Name = "browserBack"
        Me.browserBack.Size = New System.Drawing.Size(23, 22)
        Me.browserBack.Text = "ToolStripButton3"
        '
        'browserForward
        '
        Me.browserForward.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.browserForward.Image = CType(resources.GetObject("browserForward.Image"), System.Drawing.Image)
        Me.browserForward.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.browserForward.Name = "browserForward"
        Me.browserForward.Size = New System.Drawing.Size(23, 22)
        Me.browserForward.Text = "ToolStripButton4"
        '
        'browserRefresh
        '
        Me.browserRefresh.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.browserRefresh.Image = CType(resources.GetObject("browserRefresh.Image"), System.Drawing.Image)
        Me.browserRefresh.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.browserRefresh.Name = "browserRefresh"
        Me.browserRefresh.Size = New System.Drawing.Size(23, 22)
        Me.browserRefresh.Text = "ToolStripButton5"
        '
        'browserStop
        '
        Me.browserStop.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.browserStop.Image = CType(resources.GetObject("browserStop.Image"), System.Drawing.Image)
        Me.browserStop.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.browserStop.Name = "browserStop"
        Me.browserStop.Size = New System.Drawing.Size(23, 22)
        Me.browserStop.Text = "ToolStripButton6"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'browserGo
        '
        Me.browserGo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.browserGo.Image = CType(resources.GetObject("browserGo.Image"), System.Drawing.Image)
        Me.browserGo.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.browserGo.Name = "browserGo"
        Me.browserGo.Size = New System.Drawing.Size(23, 22)
        Me.browserGo.Text = "ToolStripButton7"
        '
        'browserAddress
        '
        Me.browserAddress.Name = "browserAddress"
        Me.browserAddress.Size = New System.Drawing.Size(100, 23)
        '
        'btnTestThing
        '
        Me.btnTestThing.Location = New System.Drawing.Point(136, 392)
        Me.btnTestThing.Name = "btnTestThing"
        Me.btnTestThing.Size = New System.Drawing.Size(75, 23)
        Me.btnTestThing.TabIndex = 7
        Me.btnTestThing.Text = "Test Thing"
        Me.btnTestThing.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(480, 392)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(80, 23)
        Me.btnExit.TabIndex = 8
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'ToolStripContainer1
        '
        '
        'ToolStripContainer1.BottomToolStripPanel
        '
        Me.ToolStripContainer1.BottomToolStripPanel.Controls.Add(Me.browserStatusbar)
        '
        'ToolStripContainer1.ContentPanel
        '
        Me.ToolStripContainer1.ContentPanel.Controls.Add(Me.browserWindow)
        Me.ToolStripContainer1.ContentPanel.Size = New System.Drawing.Size(536, 311)
        Me.ToolStripContainer1.LeftToolStripPanelVisible = False
        Me.ToolStripContainer1.Location = New System.Drawing.Point(16, 16)
        Me.ToolStripContainer1.Name = "ToolStripContainer1"
        Me.ToolStripContainer1.RightToolStripPanelVisible = False
        Me.ToolStripContainer1.Size = New System.Drawing.Size(536, 360)
        Me.ToolStripContainer1.TabIndex = 9
        Me.ToolStripContainer1.Text = "ToolStripContainer1"
        '
        'ToolStripContainer1.TopToolStripPanel
        '
        Me.ToolStripContainer1.TopToolStripPanel.Controls.Add(Me.ToolStrip2)
        '
        'ToolStrip2
        '
        Me.ToolStrip2.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip2.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton1, Me.ToolStripButton2})
        Me.ToolStrip2.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip2.Name = "ToolStrip2"
        Me.ToolStrip2.Size = New System.Drawing.Size(536, 25)
        Me.ToolStrip2.Stretch = True
        Me.ToolStrip2.TabIndex = 0
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton1.Text = "ToolStripButton1"
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton2.Image = CType(resources.GetObject("ToolStripButton2.Image"), System.Drawing.Image)
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Size = New System.Drawing.Size(23, 22)
        Me.ToolStripButton2.Text = "ToolStripButton2"
        '
        'ToolStripComboBoxSpring1
        '
        Me.ToolStripComboBoxSpring1.Name = "ToolStripComboBoxSpring1"
        Me.ToolStripComboBoxSpring1.Size = New System.Drawing.Size(209, 23)
        '
        'ToolStripTextBoxSpring1
        '
        Me.ToolStripTextBoxSpring1.Name = "ToolStripTextBoxSpring1"
        Me.ToolStripTextBoxSpring1.Size = New System.Drawing.Size(100, 25)
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1012, 446)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.ToolStripContainer1)
        Me.Controls.Add(Me.browserTitleStrip)
        Me.Controls.Add(Me.btnDebug)
        Me.Controls.Add(Me.btnTestThing)
        Me.Controls.Add(Me.btnExit)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.browserStatusbar.ResumeLayout(False)
        Me.browserStatusbar.PerformLayout()
        Me.browserTitleStrip.ResumeLayout(False)
        Me.browserTitleStrip.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ToolStripContainer1.BottomToolStripPanel.ResumeLayout(False)
        Me.ToolStripContainer1.BottomToolStripPanel.PerformLayout()
        Me.ToolStripContainer1.ContentPanel.ResumeLayout(False)
        Me.ToolStripContainer1.TopToolStripPanel.ResumeLayout(False)
        Me.ToolStripContainer1.TopToolStripPanel.PerformLayout()
        Me.ToolStripContainer1.ResumeLayout(False)
        Me.ToolStripContainer1.PerformLayout()
        Me.ToolStrip2.ResumeLayout(False)
        Me.ToolStrip2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents browserWindow As System.Windows.Forms.WebBrowser
    Friend WithEvents btnDebug As System.Windows.Forms.Button
    Friend WithEvents btnTestThing As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents browserStatusbar As System.Windows.Forms.StatusStrip
    Friend WithEvents browserStatusbarLabel As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents browserTitleStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents browserTitleStripLabel As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents browserToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents browserZoomIn As System.Windows.Forms.ToolStripButton
    Friend WithEvents browserZoomOut As System.Windows.Forms.ToolStripButton
    Friend WithEvents browserConfigure As System.Windows.Forms.ToolStripButton
    Friend WithEvents browserProgress As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents browserSwitchTo As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents browserSwitchToChrome As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents browserSwitchToFirefox As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents browserSwitchToIe As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents browserFavicon As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents browserHome As System.Windows.Forms.ToolStripButton
    Friend WithEvents browserSearch As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents browserBack As System.Windows.Forms.ToolStripButton
    Friend WithEvents browserForward As System.Windows.Forms.ToolStripButton
    Friend WithEvents browserRefresh As System.Windows.Forms.ToolStripButton
    Friend WithEvents browserStop As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents browserAddress As Element_Miner.ToolStripComboBoxSpring
    Friend WithEvents browserGo As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripContainer1 As System.Windows.Forms.ToolStripContainer
    Friend WithEvents ToolStrip2 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripButton2 As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripComboBoxSpring1 As Element_Miner.ToolStripComboBoxSpring
    Friend WithEvents ToolStripTextBoxSpring1 As Element_Miner.ToolStripTextBoxSpring
End Class
