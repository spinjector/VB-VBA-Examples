﻿Public Class frmLauncher_old

    'use reflection to enumerate all forms in the project, and present them in a
    'list to select/launch for development purposes

    Private currentAssembly As System.Reflection.Assembly = System.Reflection.Assembly.GetExecutingAssembly()

    Private Sub FormLoad(sender As Object, e As EventArgs) Handles MyBase.Load
        For Each t In currentAssembly.DefinedTypes
            If t.BaseType.FullName.ToString.ToUpper = "System.Windows.Forms.Form".ToUpper Then
                lstItems.Items.Add(t.FullName)
            End If
        Next
        sslItems.Text = lstItems.Items.Count.ToString & " items."
    End Sub

    Private Sub LaunchItem(sender As Object, e As EventArgs) Handles lstItems.DoubleClick, btnLaunch.Click
        If lstItems.Text <> "" Then
            Dim frmName As String = lstItems.Text
            Dim obj = currentAssembly.GetType(frmName).InvokeMember(Nothing, Reflection.BindingFlags.CreateInstance, Nothing, Nothing, Nothing)
            Dim frm As Form = CType(obj, System.Windows.Forms.Form)
            frm.Show()
            If chkCloseAfter.Checked Then Me.Close()
        End If
    End Sub

End Class