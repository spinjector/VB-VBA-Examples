﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmElementTabs
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tabGlobalId = New System.Windows.Forms.TabPage()
        Me.lstGlobalId = New System.Windows.Forms.ListBox()
        Me.tabElementList = New System.Windows.Forms.TabPage()
        Me.lstElementList = New System.Windows.Forms.ListBox()
        Me.tabXmlTree = New System.Windows.Forms.TabPage()
        Me.TreeView1 = New System.Windows.Forms.TreeView()
        Me.tabXY = New System.Windows.Forms.TabPage()
        Me.tabDeadReckoning = New System.Windows.Forms.TabPage()
        Me.TreeView2 = New System.Windows.Forms.TreeView()
        Me.tabHelp = New System.Windows.Forms.TabPage()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.tabElementProperties = New System.Windows.Forms.TabPage()
        Me.PropertyGrid1 = New System.Windows.Forms.PropertyGrid()
        Me.TabControl1.SuspendLayout()
        Me.tabGlobalId.SuspendLayout()
        Me.tabElementList.SuspendLayout()
        Me.tabXmlTree.SuspendLayout()
        Me.tabDeadReckoning.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.tabElementProperties.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.tabGlobalId)
        Me.TabControl1.Controls.Add(Me.tabElementList)
        Me.TabControl1.Controls.Add(Me.tabXmlTree)
        Me.TabControl1.Controls.Add(Me.tabXY)
        Me.TabControl1.Controls.Add(Me.tabDeadReckoning)
        Me.TabControl1.Controls.Add(Me.tabHelp)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.tabElementProperties)
        Me.TabControl1.Location = New System.Drawing.Point(16, 16)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(504, 360)
        Me.TabControl1.TabIndex = 6
        '
        'tabGlobalId
        '
        Me.tabGlobalId.Controls.Add(Me.lstGlobalId)
        Me.tabGlobalId.Location = New System.Drawing.Point(4, 22)
        Me.tabGlobalId.Name = "tabGlobalId"
        Me.tabGlobalId.Size = New System.Drawing.Size(496, 334)
        Me.tabGlobalId.TabIndex = 3
        Me.tabGlobalId.Text = "Global ID"
        Me.tabGlobalId.UseVisualStyleBackColor = True
        '
        'lstGlobalId
        '
        Me.lstGlobalId.FormattingEnabled = True
        Me.lstGlobalId.Location = New System.Drawing.Point(16, 16)
        Me.lstGlobalId.Name = "lstGlobalId"
        Me.lstGlobalId.Size = New System.Drawing.Size(344, 303)
        Me.lstGlobalId.TabIndex = 0
        '
        'tabElementList
        '
        Me.tabElementList.Controls.Add(Me.lstElementList)
        Me.tabElementList.Location = New System.Drawing.Point(4, 22)
        Me.tabElementList.Name = "tabElementList"
        Me.tabElementList.Padding = New System.Windows.Forms.Padding(3)
        Me.tabElementList.Size = New System.Drawing.Size(536, 334)
        Me.tabElementList.TabIndex = 0
        Me.tabElementList.Text = "Element List"
        Me.tabElementList.UseVisualStyleBackColor = True
        '
        'lstElementList
        '
        Me.lstElementList.FormattingEnabled = True
        Me.lstElementList.Location = New System.Drawing.Point(16, 16)
        Me.lstElementList.MultiColumn = True
        Me.lstElementList.Name = "lstElementList"
        Me.lstElementList.Size = New System.Drawing.Size(344, 303)
        Me.lstElementList.TabIndex = 5
        '
        'tabXmlTree
        '
        Me.tabXmlTree.Controls.Add(Me.TreeView1)
        Me.tabXmlTree.Location = New System.Drawing.Point(4, 22)
        Me.tabXmlTree.Name = "tabXmlTree"
        Me.tabXmlTree.Padding = New System.Windows.Forms.Padding(3)
        Me.tabXmlTree.Size = New System.Drawing.Size(536, 334)
        Me.tabXmlTree.TabIndex = 1
        Me.tabXmlTree.Text = "XML Tree"
        Me.tabXmlTree.UseVisualStyleBackColor = True
        '
        'TreeView1
        '
        Me.TreeView1.Location = New System.Drawing.Point(16, 16)
        Me.TreeView1.Name = "TreeView1"
        Me.TreeView1.Size = New System.Drawing.Size(344, 296)
        Me.TreeView1.TabIndex = 6
        '
        'tabXY
        '
        Me.tabXY.Location = New System.Drawing.Point(4, 22)
        Me.tabXY.Name = "tabXY"
        Me.tabXY.Size = New System.Drawing.Size(536, 334)
        Me.tabXY.TabIndex = 5
        Me.tabXY.Text = "X-Y"
        Me.tabXY.UseVisualStyleBackColor = True
        '
        'tabDeadReckoning
        '
        Me.tabDeadReckoning.Controls.Add(Me.TreeView2)
        Me.tabDeadReckoning.Location = New System.Drawing.Point(4, 22)
        Me.tabDeadReckoning.Name = "tabDeadReckoning"
        Me.tabDeadReckoning.Padding = New System.Windows.Forms.Padding(3)
        Me.tabDeadReckoning.Size = New System.Drawing.Size(536, 334)
        Me.tabDeadReckoning.TabIndex = 2
        Me.tabDeadReckoning.Text = "Dead Reckoning"
        Me.tabDeadReckoning.UseVisualStyleBackColor = True
        '
        'TreeView2
        '
        Me.TreeView2.Location = New System.Drawing.Point(16, 16)
        Me.TreeView2.Name = "TreeView2"
        Me.TreeView2.Size = New System.Drawing.Size(344, 296)
        Me.TreeView2.TabIndex = 7
        '
        'tabHelp
        '
        Me.tabHelp.Location = New System.Drawing.Point(4, 22)
        Me.tabHelp.Name = "tabHelp"
        Me.tabHelp.Size = New System.Drawing.Size(536, 334)
        Me.tabHelp.TabIndex = 4
        Me.tabHelp.Text = "Help"
        Me.tabHelp.UseVisualStyleBackColor = True
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.ListView1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(536, 334)
        Me.TabPage1.TabIndex = 6
        Me.TabPage1.Text = "TabPage1"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'ListView1
        '
        Me.ListView1.Location = New System.Drawing.Point(16, 16)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(344, 296)
        Me.ListView1.TabIndex = 0
        Me.ListView1.UseCompatibleStateImageBehavior = False
        '
        'tabElementProperties
        '
        Me.tabElementProperties.Controls.Add(Me.PropertyGrid1)
        Me.tabElementProperties.Location = New System.Drawing.Point(4, 22)
        Me.tabElementProperties.Name = "tabElementProperties"
        Me.tabElementProperties.Padding = New System.Windows.Forms.Padding(3)
        Me.tabElementProperties.Size = New System.Drawing.Size(536, 334)
        Me.tabElementProperties.TabIndex = 7
        Me.tabElementProperties.Text = "Properties"
        Me.tabElementProperties.UseVisualStyleBackColor = True
        '
        'PropertyGrid1
        '
        Me.PropertyGrid1.Location = New System.Drawing.Point(60, 18)
        Me.PropertyGrid1.Name = "PropertyGrid1"
        Me.PropertyGrid1.Size = New System.Drawing.Size(248, 270)
        Me.PropertyGrid1.TabIndex = 1
        '
        'frmElementTabs
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(535, 393)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "frmElementTabs"
        Me.Text = "frmElementTabs"
        Me.TabControl1.ResumeLayout(False)
        Me.tabGlobalId.ResumeLayout(False)
        Me.tabElementList.ResumeLayout(False)
        Me.tabXmlTree.ResumeLayout(False)
        Me.tabDeadReckoning.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.tabElementProperties.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tabGlobalId As System.Windows.Forms.TabPage
    Friend WithEvents lstGlobalId As System.Windows.Forms.ListBox
    Friend WithEvents tabElementList As System.Windows.Forms.TabPage
    Friend WithEvents lstElementList As System.Windows.Forms.ListBox
    Friend WithEvents tabXmlTree As System.Windows.Forms.TabPage
    Friend WithEvents TreeView1 As System.Windows.Forms.TreeView
    Friend WithEvents tabXY As System.Windows.Forms.TabPage
    Friend WithEvents tabDeadReckoning As System.Windows.Forms.TabPage
    Friend WithEvents TreeView2 As System.Windows.Forms.TreeView
    Friend WithEvents tabHelp As System.Windows.Forms.TabPage
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents tabElementProperties As System.Windows.Forms.TabPage
    Friend WithEvents PropertyGrid1 As System.Windows.Forms.PropertyGrid
End Class
