﻿
Imports System.Xml

Public Class frmMain

    Private Sub Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        browserNavigate(browserWindow, My.Settings.browserHomePage)
    End Sub

    Private Sub browserWindow_DocumentCompleted(sender As Object, e As WebBrowserDocumentCompletedEventArgs) Handles browserWindow.DocumentCompleted
        browserAddress.Text = browserWindow.Url.ToString
        'ElementListPopulate(browserWindow, lstElementList)
    End Sub

    Private Sub browserWindow_Navigated(sender As Object, e As WebBrowserNavigatedEventArgs) Handles browserWindow.Navigated
        WebBrowserPerformZoom(Me.browserWindow, 50)
    End Sub

    Private Sub btnDebug_Click(sender As Object, e As EventArgs) Handles btnDebug.Click
        Stop
    End Sub

    ' Automatically selects URL text when address textbox is clicked on
    Private Sub browserAddress_Click(sender As Object, e As EventArgs)
        browserAddress.SelectAll()
    End Sub

    ' Navigates to the URL in the address box when the ENTER key is pressed while the ToolStripTextBox has focus.
    Private Sub browserAddress_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs)
        If (e.KeyCode = Keys.Enter) Then
            browserNavigate(browserWindow, browserAddress.Text)
        End If
    End Sub

    ' Navigates to the URL in the address box when the Go button is clicked.
    Private Sub browserGo_Click(ByVal sender As Object, ByVal e As EventArgs)
        browserNavigate(browserWindow, browserAddress.Text)
    End Sub

    ' Navigates browserWindow to the previous page in the history.
    Private Sub browserback_Click(ByVal sender As Object, ByVal e As EventArgs)
        browserWindow.GoBack()
    End Sub

    ' Disables the Back button at the beginning of the navigation history.
    Private Sub browserWindow_CanGoBackChanged(ByVal sender As Object, ByVal e As EventArgs) Handles browserWindow.CanGoBackChanged
        browserBack.Enabled = browserWindow.CanGoBack
    End Sub

    ' Navigates browserWindow to the next page in history.
    Private Sub browserforward_Click(ByVal sender As Object, ByVal e As EventArgs)
        browserWindow.GoForward()
    End Sub

    ' Disables the Forward button at the end of navigation history.
    Private Sub browserWindow_CanGoForwardChanged(ByVal sender As Object, ByVal e As EventArgs) Handles browserWindow.CanGoForwardChanged
        browserForward.Enabled = browserWindow.CanGoForward
    End Sub

    ' Halts the current navigation and any sounds or animations on 
    ' the page.
    Private Sub browserStop_Click(ByVal sender As Object, ByVal e As EventArgs)
        browserWindow.Stop()
    End Sub

    ' Reloads the current page.
    Private Sub browserRefresh_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' Skip refresh if about:blank is loaded to avoid removing
        ' content specified by the DocumentText property.
        If Not browserWindow.Url.Equals("about:blank") Then
            browserWindow.Refresh()
        End If
    End Sub

    ' Navigates browserWindow to the home page of the current user.
    Private Sub browserhome_Click(ByVal sender As Object, ByVal e As EventArgs)
        browserWindow.GoHome()
    End Sub

    ' Navigates browserWindow to the search page of the current user.
    Private Sub browsersearch_Click(ByVal sender As Object, ByVal e As EventArgs)
        browserWindow.GoSearch()
    End Sub
    ' Updates the status bar with the current browser status text.
    Private Sub browserWindow_StatusTextChanged(ByVal sender As Object, ByVal e As EventArgs) Handles browserWindow.StatusTextChanged
        browserStatusbarLabel.Text = browserWindow.StatusText
    End Sub

    ' Updates the title bar with the current document title.
    Private Sub browserWindow_DocumentTitleChanged(ByVal sender As Object, ByVal e As EventArgs) Handles browserWindow.DocumentTitleChanged
        browserTitleStripLabel.Text = browserWindow.DocumentTitle
        ' Updates the URL in TextBoxAddress upon navigation.
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub

    Private Sub browserConfigure_Click(sender As Object, e As EventArgs) Handles browserConfigure.Click
        frmSettings.ShowDialog()
    End Sub

    Private Sub browserZoomOut_Click(sender As Object, e As EventArgs) Handles browserZoomOut.Click

    End Sub

    Private Sub browserWindow_ProgressChanged(sender As Object, e As WebBrowserProgressChangedEventArgs) Handles browserWindow.ProgressChanged
        Dim percent As Integer
        Dim current As Integer
        Dim maximum As Integer
        current = e.CurrentProgress
        maximum = e.MaximumProgress
        If maximum < 1 Then maximum = 1
        percent = Int(current / maximum) * 100
        If percent > 100 Or percent < 0 Then Exit Sub
        browserProgress.Value = percent
    End Sub

    Private Sub browserWindow_Navigating(sender As Object, e As WebBrowserNavigatingEventArgs) Handles browserWindow.Navigating
        'lstElementList.Items.Clear()
    End Sub

    Private Sub browserSwitchToChrome_Click(sender As Object, e As EventArgs) Handles browserSwitchToChrome.Click
        notYetImplmented()
    End Sub

    Private Sub RandomStuff()

    End Sub

End Class

