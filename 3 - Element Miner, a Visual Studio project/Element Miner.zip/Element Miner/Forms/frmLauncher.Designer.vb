﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLauncher_old
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstItems = New System.Windows.Forms.ListBox()
        Me.lblItems = New System.Windows.Forms.Label()
        Me.btnLaunch = New System.Windows.Forms.Button()
        Me.tscItems = New System.Windows.Forms.ToolStripContainer()
        Me.ssItems = New System.Windows.Forms.StatusStrip()
        Me.sslItems = New System.Windows.Forms.ToolStripStatusLabel()
        Me.chkCloseAfter = New System.Windows.Forms.CheckBox()
        Me.tscItems.BottomToolStripPanel.SuspendLayout()
        Me.tscItems.ContentPanel.SuspendLayout()
        Me.tscItems.SuspendLayout()
        Me.ssItems.SuspendLayout()
        Me.SuspendLayout()
        '
        'lstItems
        '
        Me.lstItems.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lstItems.FormattingEnabled = True
        Me.lstItems.IntegralHeight = False
        Me.lstItems.Location = New System.Drawing.Point(0, 0)
        Me.lstItems.Name = "lstItems"
        Me.lstItems.Size = New System.Drawing.Size(256, 242)
        Me.lstItems.TabIndex = 0
        '
        'lblItems
        '
        Me.lblItems.AutoSize = True
        Me.lblItems.Location = New System.Drawing.Point(16, 16)
        Me.lblItems.Name = "lblItems"
        Me.lblItems.Size = New System.Drawing.Size(210, 13)
        Me.lblItems.TabIndex = 1
        Me.lblItems.Text = "Double-click an item to launch it for testing:"
        '
        'btnLaunch
        '
        Me.btnLaunch.Location = New System.Drawing.Point(192, 320)
        Me.btnLaunch.Name = "btnLaunch"
        Me.btnLaunch.Size = New System.Drawing.Size(80, 23)
        Me.btnLaunch.TabIndex = 2
        Me.btnLaunch.Text = "Launch"
        Me.btnLaunch.UseVisualStyleBackColor = True
        '
        'tscItems
        '
        '
        'tscItems.BottomToolStripPanel
        '
        Me.tscItems.BottomToolStripPanel.Controls.Add(Me.ssItems)
        '
        'tscItems.ContentPanel
        '
        Me.tscItems.ContentPanel.Controls.Add(Me.lstItems)
        Me.tscItems.ContentPanel.Size = New System.Drawing.Size(256, 242)
        Me.tscItems.LeftToolStripPanelVisible = False
        Me.tscItems.Location = New System.Drawing.Point(16, 40)
        Me.tscItems.Name = "tscItems"
        Me.tscItems.RightToolStripPanelVisible = False
        Me.tscItems.Size = New System.Drawing.Size(256, 264)
        Me.tscItems.TabIndex = 3
        Me.tscItems.TopToolStripPanelVisible = False
        '
        'ssItems
        '
        Me.ssItems.Dock = System.Windows.Forms.DockStyle.None
        Me.ssItems.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.sslItems})
        Me.ssItems.Location = New System.Drawing.Point(0, 0)
        Me.ssItems.Name = "ssItems"
        Me.ssItems.Size = New System.Drawing.Size(256, 22)
        Me.ssItems.SizingGrip = False
        Me.ssItems.TabIndex = 0
        '
        'sslItems
        '
        Me.sslItems.Name = "sslItems"
        Me.sslItems.Size = New System.Drawing.Size(241, 17)
        Me.sslItems.Spring = True
        Me.sslItems.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'chkCloseAfter
        '
        Me.chkCloseAfter.AutoSize = True
        Me.chkCloseAfter.Checked = True
        Me.chkCloseAfter.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkCloseAfter.Location = New System.Drawing.Point(24, 320)
        Me.chkCloseAfter.Name = "chkCloseAfter"
        Me.chkCloseAfter.Size = New System.Drawing.Size(153, 17)
        Me.chkCloseAfter.TabIndex = 7
        Me.chkCloseAfter.Text = "Close this form after launch"
        Me.chkCloseAfter.UseVisualStyleBackColor = True
        '
        'frmLauncher_old
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(289, 361)
        Me.Controls.Add(Me.chkCloseAfter)
        Me.Controls.Add(Me.tscItems)
        Me.Controls.Add(Me.btnLaunch)
        Me.Controls.Add(Me.lblItems)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "frmLauncher_old"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Project Item Launcher"
        Me.tscItems.BottomToolStripPanel.ResumeLayout(False)
        Me.tscItems.BottomToolStripPanel.PerformLayout()
        Me.tscItems.ContentPanel.ResumeLayout(False)
        Me.tscItems.ResumeLayout(False)
        Me.tscItems.PerformLayout()
        Me.ssItems.ResumeLayout(False)
        Me.ssItems.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lstItems As System.Windows.Forms.ListBox
    Friend WithEvents lblItems As System.Windows.Forms.Label
    Friend WithEvents btnLaunch As System.Windows.Forms.Button
    Friend WithEvents tscItems As System.Windows.Forms.ToolStripContainer
    Friend WithEvents ssItems As System.Windows.Forms.StatusStrip
    Friend WithEvents sslItems As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents chkCloseAfter As System.Windows.Forms.CheckBox
End Class
